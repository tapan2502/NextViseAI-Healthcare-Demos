export const I18N = {
  en: {
    brand: "NextViseAI — Healthcare Demos",
    tabs: { th: "Telehealth", tp: "Tele-Pharmacy" },
    lang: "Language",
    consent:
      "I consent to receive demo messages (SMS/WhatsApp/Email). This is a demo and not medical advice.",
    name: "Name",
    phone: "Mobile number",
    email: "Email",
    or: "or",
    // Telehealth
    thTitle: "Try our Telehealth Agent",
    thSub:
      "Talk to an AI assistant that books appointments, sends SMS/WhatsApp follow-ups, and can hand off to a live doctor.",
    startAgent: "Start Voice Agent",
    scheduleNow: "Schedule now",
    avatarDemo: "Avatar Tele-Consultation (Demo)",
    transcript: "Transcript",
    summary: "Visit Summary",
    doctorHandoff: "Book Doctor (e-Prescription)",
    genErx: "Generate e-Rx (Demo)",
    sickNote: "Request Sick Note (Demo)",
    // Tele-Pharmacy
    tpTitle: "Ask the Pharmacist Avatar",
    tpSub:
      "Get product guidance, usage instructions, and precautions. The avatar can book a follow-up and send you a summary.",
    chooseProduct: "Choose a product (demo)",
    add: "Add",
    cart: "Cart",
    qty: "Qty",
    sendSummary: "Send summary",
    channel: "Channel",
    sms: "SMS",
    whatsapp: "WhatsApp",
    emailCh: "Email",
    // Sick Note modal
    snTitle: "Sick Note (Demo)",
    reason: "Reason / Symptoms",
    startDate: "Start date",
    duration: "Duration (days)",
    country: "Country",
    employerEmail: "Employer email (optional)",
    create: "Create",
    cancel: "Cancel",
    footer:
      "Demo only • HIPAA/GDPR aware flow • Do not enter real PHI.",
    // Additional UI strings
    contactInfo: "Contact Information",
    contactDesc:
      "Enter your details to access the healthcare demos",
    fullName: "Your full name",
    phoneNumber: "+1 (555) 000-0000",
    emailAddress: "your@email.com",
    consentLabel: "Healthcare Demo Consent:",
    consentText:
      "I consent to receive demo messages (SMS/WhatsApp/Email). This is a demonstration platform and not actual medical advice. All data is handled in compliance with HIPAA/GDPR standards.",
    visitSummaryDesc:
      "Real-time transcript and medical summary generation",
    generateSummary: "Generate Summary",
    ePrescriptionDesc:
      "Digital prescription generation and pharmacy integration",
    sickNoteDesc:
      "Official medical certificate generation for employers",
    doctorHandoffTitle: "Doctor Handoff System",
    doctorHandoffDesc:
      "Seamless transition from AI to human healthcare providers",
    bookDoctor: "Book Doctor Consultation",
    emergencyConsult: "Emergency Consultation",
    productCatalog: "Product Catalog (Demo)",
    pharmacistAvatar: "Pharmacist Avatar",
    askProducts: "Ask About Products",
    getInstructions: "Get Usage Instructions",
    sendFollowup: "Send Summary & Follow-up",
    preferredChannel: "Preferred Channel",
    language: "Language",
    summaryType: "Summary Type",
    consultationSummary: "Consultation Summary",
    productInfo: "Product Information",
    prescriptionDetails: "Prescription Details",

    // NEW: per-product translations (EN)
    products: {
      acetaminophen_500: {
        name: "Acetaminophen 500mg",
        subtitle: "Acetaminophen 500mg",
        description: "Gentle pain relief and fever reducer",
      },
      adhesive_bandages: {
        name: "Adhesive Bandages (Mixed Sizes)",
        subtitle: "N/A N/A",
        description:
          "Sterile adhesive bandages for minor cuts and scrapes",
      },
      antacid_tablets: {
        name: "Antacid Tablets",
        subtitle: "Calcium Carbonate 500mg",
        description:
          "Fast relief from heartburn and acid indigestion",
      },
      cetirizine_10: {
        name: "Cetirizine 10mg",
        subtitle: "Cetirizine HCl 10mg",
        description:
          "24-hour allergy relief for hay fever and hives",
      },
      dextromethorphan_syrup: {
        name: "Dextromethorphan Cough Syrup",
        subtitle: "Dextromethorphan HBr 15mg/5ml",
        description: "Effective cough suppressant for dry coughs",
      },
      ibuprofen_200: {
        name: "Ibuprofen 200mg",
        subtitle: "Ibuprofen 200mg",
        description:
          "Fast-acting pain relief for headaches, muscle pain, and inflammation",
      },
      loratadine_10: {
        name: "Loratadine 10mg",
        subtitle: "Loratadine 10mg",
        description:
          "Non-drowsy allergy relief for seasonal allergies",
      },
      vitamin_d3_1000: {
        name: "Vitamin D3 1000 IU",
        subtitle: "Cholecalciferol 1000 IU",
        description:
          "Essential vitamin for bone health and immunity",
      },
    },
  },

  de: {
    brand: "NextViseAI — Healthcare-Demos",
    tabs: { th: "Telehealth", tp: "Tele-Pharmacy" },
    lang: "Sprache",
    consent:
      "Ich stimme zu, Demo-Nachrichten (SMS/WhatsApp/E-Mail) zu erhalten. Dies ist nur eine Demo und keine medizinische Beratung.",
    name: "Name",
    phone: "Handynummer",
    email: "E-Mail",
    or: "oder",
    thTitle: "Testen Sie unseren Telehealth-Agenten",
    thSub:
      "Sprechen Sie mit einem KI-Assistenten, der Termine bucht, Follow-ups sendet und an einen Live-Arzt übergibt.",
    startAgent: "Voice-Agent starten",
    scheduleNow: "Jetzt Termin buchen",
    avatarDemo: "Avatar-Telekonsultation (Demo)",
    transcript: "Transkript",
    summary: "Besuchs-Zusammenfassung",
    doctorHandoff: "Arzt buchen (E-Rezept)",
    genErx: "E-Rezept erzeugen (Demo)",
    sickNote: "Krankschreibung anfordern (Demo)",
    tpTitle: "Fragen Sie den Apotheker-Avatar",
    tpSub:
      "Produkthinweise, Anwendung und Vorsicht. Avatar kann Follow-ups buchen und Zusammenfassung senden.",
    chooseProduct: "Produkt wählen (Demo)",
    add: "Hinzufügen",
    cart: "Warenkorb",
    qty: "Menge",
    sendSummary: "Zusammenfassung senden",
    channel: "Kanal",
    sms: "SMS",
    whatsapp: "WhatsApp",
    emailCh: "E-Mail",
    snTitle: "Krankschreibung (Demo)",
    reason: "Grund / Symptome",
    startDate: "Beginn",
    duration: "Dauer (Tage)",
    country: "Land",
    employerEmail: "Arbeitgeber-E-Mail (optional)",
    create: "Erstellen",
    cancel: "Abbrechen",
    footer:
      "Nur Demo • HIPAA/GDPR-bewusster Ablauf • Keine echten Gesundheitsdaten eingeben.",
    contactInfo: "Kontaktinformationen",
    contactDesc:
      "Geben Sie Ihre Daten ein, um auf die Healthcare-Demos zuzugreifen",
    fullName: "Ihr vollständiger Name",
    phoneNumber: "+49 (0) 000 000000",
    emailAddress: "ihre@email.com",
    consentLabel: "Healthcare Demo Einverständnis:",
    consentText:
      "Ich stimme zu, Demo-Nachrichten (SMS/WhatsApp/E-Mail) zu erhalten. Dies ist eine Demo-Plattform und keine echte medizinische Beratung. Alle Daten werden HIPAA/GDPR-konform behandelt.",
    visitSummaryDesc:
      "Echtzeit-Transkript und medizinische Zusammenfassung",
    generateSummary: "Zusammenfassung erstellen",
    ePrescriptionDesc:
      "Digitale Rezepterstellung und Apothekenintegration",
    sickNoteDesc:
      "Offizielle Krankschreibung für Arbeitgeber",
    doctorHandoffTitle: "Arzt-Übergabesystem",
    doctorHandoffDesc:
      "Nahtloser Übergang von KI zu menschlichen Gesundheitsdienstleistern",
    bookDoctor: "Arzttermin buchen",
    emergencyConsult: "Notfallkonsultation",
    productCatalog: "Produktkatalog (Demo)",
    pharmacistAvatar: "Apotheker-Avatar",
    askProducts: "Nach Produkten fragen",
    getInstructions: "Anwendungshinweise",
    sendFollowup: "Zusammenfassung & Nachbetreuung senden",
    preferredChannel: "Bevorzugter Kanal",
    language: "Sprache",
    summaryType: "Zusammenfassungstyp",
    consultationSummary: "Beratungszusammenfassung",
    productInfo: "Produktinformationen",
    prescriptionDetails: "Rezeptdetails",

    // NEW: per-product translations (DE)
    products: {
      acetaminophen_500: {
        name: "Acetaminophen 500mg",
        subtitle: "Acetaminophen 500mg",
        description: "Sanfte Schmerzlinderung und Fiebersenkung",
      },
      adhesive_bandages: {
        name: "Pflaster (Gemischte Größen)",
        subtitle: "k. A.",
        description:
          "Sterile Pflaster für kleine Schnitte und Schürfwunden",
      },
      antacid_tablets: {
        name: "Antazida Tabletten",
        subtitle: "Calciumcarbonat 500mg",
        description:
          "Schnelle Linderung bei Sodbrennen und saurer Verdauung",
      },
      cetirizine_10: {
        name: "Cetirizin 10mg",
        subtitle: "Cetirizinhydrochlorid 10mg",
        description:
          "24-Stunden Allergielinderung bei Heuschnupfen und Nesselsucht",
      },
      dextromethorphan_syrup: {
        name: "Dextromethorphan Hustensaft",
        subtitle: "Dextromethorphan HBr 15mg/5ml",
        description: "Wirksamer Hustenstiller bei Reizhusten",
      },
      ibuprofen_200: {
        name: "Ibuprofen 200mg",
        subtitle: "Ibuprofen 200mg",
        description:
          "Schnelle Linderung bei Kopfschmerzen, Muskelschmerzen und Entzündungen",
      },
      loratadine_10: {
        name: "Loratadin 10mg",
        subtitle: "Loratadin 10mg",
        description:
          "Nicht müde machende Allergielinderung bei Heuschnupfen",
      },
      vitamin_d3_1000: {
        name: "Vitamin D3 1000 IE",
        subtitle: "Cholecalciferol 1000 IE",
        description:
          "Wichtiges Vitamin für Knochen und Immunsystem",
      },
    },
  },

  ar: {
    brand: "NextViseAI — عروض تجريبية صحية",
    tabs: { th: "الصحة عن بُعد", tp: "الصيدلة عن بُعد" },
    lang: "اللغة",
    consent:
      "أوافق على استلام رسائل تجريبية (SMS/واتساب/البريد). هذا عرض تجريبي وليس نصيحة طبية.",
    name: "الاسم",
    phone: "رقم الجوال",
    email: "البريد الإلكتروني",
    or: "أو",
    thTitle: "جرّب وكيل الصحة عن بُعد",
    thSub:
      "تحدث مع وكيل يحجز المواعيد ويرسل المتابعات ويمكنه التحويل لطبيب مباشر.",
    startAgent: "بدء الوكيل الصوتي",
    scheduleNow: "احجز الآن",
    avatarDemo: "استشارة أفاتار (تجريبي)",
    transcript: "النص الحرفي",
    summary: "ملخص الزيارة",
    doctorHandoff: "حجز طبيب (وصفة إلكترونية)",
    genErx: "إنشاء وصفة إلكترونية (تجريبي)",
    sickNote: "طلب إجازة مرضية (تجريبي)",
    tpTitle: "اسأل أفاتار الصيدلي",
    tpSub:
      "إرشادات المنتج والاستخدام والاحتياطات. يمكنه حجز المتابعة وإرسال ملخص.",
    chooseProduct: "اختر منتجًا (تجريبي)",
    add: "إضافة",
    cart: "السلة",
    qty: "الكمية",
    sendSummary: "إرسال الملخص",
    channel: "القناة",
    sms: "SMS",
    whatsapp: "واتساب",
    emailCh: "البريد",
    snTitle: "إجازة مرضية (تجريبي)",
    reason: "السبب/الأعراض",
    startDate: "تاريخ البدء",
    duration: "المدة (أيام)",
    country: "الدولة",
    employerEmail: "بريد صاحب العمل (اختياري)",
    create: "إنشاء",
    cancel: "إلغاء",
    footer:
      "عرض تجريبي فقط • مراعاة HIPAA/GDPR • تجنب إدخال بيانات صحية حقيقية.",
    contactInfo: "معلومات الاتصال",
    contactDesc:
      "أدخل بياناتك للوصول إلى العروض التجريبية الصحية",
    fullName: "اسمك الكامل",
    phoneNumber: "+966 5X XXX XXXX",
    emailAddress: "بريدك@الإلكتروني.com",
    consentLabel: "موافقة العرض التجريبي الصحي:",
    consentText:
      "أوافق على استلام رسائل تجريبية (SMS/واتساب/البريد الإلكتروني). هذه منصة عرض تجريبي وليست استشارة طبية فعلية. جميع البيانات تتم معالجتها وفقاً لمعايير HIPAA/GDPR.",
    visitSummaryDesc:
      "نسخة فورية وملخص طبي في الوقت الفعلي",
    generateSummary: "إنشاء الملخص",
    ePrescriptionDesc:
      "إنشاء وصفة رقمية وتكامل مع الصيدلية",
    sickNoteDesc:
      "إنشاء شهادة طبية رسمية لأصحاب العمل",
    doctorHandoffTitle: "نظام التحويل للطبيب",
    doctorHandoffDesc:
      "انتقال سلس من الذكاء الاصطناعي إلى مقدمي الرعاية الصحية البشرية",
    bookDoctor: "حجز استشارة طبيب",
    emergencyConsult: "استشارة طارئة",
    productCatalog: "كتالوج المنتجات (تجريبي)",
    pharmacistAvatar: "أفاتار الصيدلي",
    askProducts: "اسأل عن المنتجات",
    getInstructions: "احصل على تعليمات الاستخدام",
    sendFollowup: "إرسال الملخص والمتابعة",
    preferredChannel: "القناة المفضلة",
    language: "اللغة",
    summaryType: "نوع الملخص",
    consultationSummary: "ملخص الاستشارة",
    productInfo: "معلومات المنتج",
    prescriptionDetails: "تفاصيل الوصفة",

    // NEW: per-product translations (AR)
    products: {
      acetaminophen_500: {
        name: "أسيتامينوفين 500 ملغ",
        subtitle: "أسيتامينوفين 500 ملغ",
        description: "مسكن خفيف للآلام وخافض للحرارة",
      },
      adhesive_bandages: {
        name: "ضمادات لاصقة (مقاسات متنوعة)",
        subtitle: "N/A",
        description:
          "ضمادات معقمة للجروح والخدوش البسيطة",
      },
      antacid_tablets: {
        name: "أقراص مضاد للحموضة",
        subtitle: "كربونات الكالسيوم 500 ملغ",
        description:
          "تخفيف سريع لحرقة المعدة والحموضة",
      },
      cetirizine_10: {
        name: "سيتريزين 10 ملغ",
        subtitle: "هيدروكلوريد سيتريزين 10 ملغ",
        description:
          "تخفيف الحساسية لمدة 24 ساعة لحُمّى القش والشرى",
      },
      dextromethorphan_syrup: {
        name: "شراب ديكستروميثورفان للسعال",
        subtitle: "ديكستروميثورفان هبر 15 ملغ/5 مل",
        description: "مثبط فعّال للسعال الجاف",
      },
      ibuprofen_200: {
        name: "إيبوبروفين 200 ملغ",
        subtitle: "إيبوبروفين 200 ملغ",
        description:
          "تسكين سريع للصداع وآلام العضلات والالتهاب",
      },
      loratadine_10: {
        name: "لوراتادين 10 ملغ",
        subtitle: "لوراتادين 10 ملغ",
        description: "تخفيف حساسية لا يسبب النعاس",
      },
      vitamin_d3_1000: {
        name: "فيتامين د3 1000 وحدة",
        subtitle: "كولي كالسيفيرول 1000 وحدة",
        description:
          "فيتامين أساسي لصحة العظام والمناعة",
      },
    },
  },
} as const;

export type LangKey = keyof typeof I18N;

// NOTE: the old `export const DEMO_PRODUCTS = [...]` is intentionally removed
// to keep i18n.ts clean and translation-only.
